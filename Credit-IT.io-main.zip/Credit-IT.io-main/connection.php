<?php 
    //FOR DEVOPS THERE IS TWO ANOTHER CONNECTION IN 'nav.php' and 'login.php' SO MAKE CHANGES IN THAT ALSO.
    $connection = mysqli_connect('localhost', 'root', '', 'creditit');
    session_start();
?>